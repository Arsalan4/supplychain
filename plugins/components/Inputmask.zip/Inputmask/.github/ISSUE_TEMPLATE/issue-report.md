---
name: Issue report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
Say it.  Spit it out.  What is it exactly?

**Live example**
Add a link to a codepen, jsfiddle or other example page which shows the problem

**Please complete the following information:**
 - OS:
 - Browser
 - Inputmask version 

**Additional context**
How do you feel?  Do you want to talk about?  Why do you care?  ;-)
